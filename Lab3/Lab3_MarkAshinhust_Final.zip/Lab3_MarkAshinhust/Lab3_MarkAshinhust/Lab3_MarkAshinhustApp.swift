//
//  Lab3_MarkAshinhustApp.swift
//  Lab3_MarkAshinhust
//
//  Created by Mark Ashinhust on 2/22/23.
//

import SwiftUI

@main
struct Lab3_MarkAshinhustApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
